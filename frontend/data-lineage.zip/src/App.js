import React from "react";
import MDLPage from "./pages/MDLPage";

function App() {
  return (
    <MDLPage />
  );
}

export default App;