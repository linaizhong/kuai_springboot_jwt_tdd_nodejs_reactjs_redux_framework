import React, {Component} from 'react';
import MDLViewer from "../viewer/MDLViewer";

export default class MDLPage extends Component {
    constructor(props) {
        super(props);

        this.state = {
            sbcm: {},
            showSuccessMessage: false
        }

        this.fgRef = React.createRef()
        this.refreshFiles = this.refreshFiles.bind(this)
        this.nodeHoverTooltip = this.nodeHoverTooltip.bind(this)
    }

    componentDidMount() {
        // this.refreshFiles();
    }

    refreshFiles() {
    }

    nodeHoverTooltip(node) {
        return `<div>
          <b>${node.name}</b>
        </div>`;
    }

    render() {
        return (<MDLViewer width={700} height={700}></MDLViewer>)
    }
}
