export const alertConstants = {
    SUCCESS: 'ALERT/SUCCESS',
    ERROR: 'ALERT/ERROR',
    CLEAR: 'ALERT/CLEAR'
};
