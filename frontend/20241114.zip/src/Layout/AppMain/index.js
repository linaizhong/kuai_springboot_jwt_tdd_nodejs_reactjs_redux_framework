import {Route, Redirect} from 'react-router-dom';
import React, {Suspense, lazy, Fragment, Component} from 'react';
import Loader from 'react-loaders'

import {
    ToastContainer,
} from 'react-toastify';
import {PrivateRoute} from "../../_components";

// const Extras = lazy(() => import ('../../Pages/Extras'));
const NswEducationalDocument = lazy(() => import('../../Pages/NswEducationalDocument'));
// const DigitalResourcesPages = lazy(() => import('../../Pages/DigitalResources'));
// const OperationalKnowledgeHubPages = lazy(() => import('../../Pages/OperationalKnowledgeHub'));
// const EducationalDataLakePages = lazy(() => import('../../Pages/EducationalDataLake'));
// const LearningAnalyticsPages = lazy(() => import('../../Pages/LearningAnalytics'));
// const KafkaSIFStudentData = lazy(() => import('../../Pages/KafkaSIFStudentData'));

class AppMain extends Component {
    render() {
        return (
            <Fragment>
                <Suspense fallback={
                    <div className="loader-container">
                        <div className="loader-container-inner">
                            <div className="text-center">
                                <Loader type="ball-grid-beat"/>
                            </div>
                        </div>
                    </div>}>
                    <PrivateRoute path="/nsw-edu-docs" component={NswEducationalDocument}/>
                </Suspense>
                {/*<Suspense fallback={*/}
                {/*    <div className="loader-container">*/}
                {/*        <div className="loader-container-inner">*/}
                {/*            <div className="text-center">*/}
                {/*                <Loader type="ball-grid-beat"/>*/}
                {/*            </div>*/}
                {/*        </div>*/}
                {/*    </div>}>*/}
                {/*    <PrivateRoute path="/okh" component={OperationalKnowledgeHubPages}/>*/}
                {/*</Suspense>*/}
                {/*<Suspense fallback={*/}
                {/*    <div className="loader-container">*/}
                {/*        <div className="loader-container-inner">*/}
                {/*            <div className="text-center">*/}
                {/*                <Loader type="ball-grid-beat"/>*/}
                {/*            </div>*/}
                {/*        </div>*/}
                {/*    </div>}>*/}
                {/*    <PrivateRoute path="/sifdata" component={KafkaSIFStudentData}/>*/}
                {/*</Suspense>*/}
                {/*<Suspense fallback={*/}
                {/*    <div className="loader-container">*/}
                {/*        <div className="loader-container-inner">*/}
                {/*            <div className="text-center">*/}
                {/*                <Loader type="ball-grid-beat"/>*/}
                {/*            </div>*/}
                {/*        </div>*/}
                {/*    </div>}>*/}
                {/*    <PrivateRoute path="/la" component={LearningAnalyticsPages}/>*/}
                {/*</Suspense>*/}
                {/*<Suspense fallback={*/}
                {/*    <div className="loader-container">*/}
                {/*        <div className="loader-container-inner">*/}
                {/*            <div className="text-center">*/}
                {/*                <Loader type="ball-grid-beat"/>*/}
                {/*            </div>*/}
                {/*        </div>*/}
                {/*    </div>}>*/}
                {/*    <PrivateRoute path="/datalake" component={EducationalDataLakePages}/>*/}
                {/*</Suspense>*/}
                {/*<Suspense fallback={*/}
                {/*    <div className="loader-container">*/}
                {/*        <div className="loader-container-inner">*/}
                {/*            <div className="text-center">*/}
                {/*                <Loader type="ball-grid-beat"/>*/}
                {/*            </div>*/}
                {/*        </div>*/}
                {/*    </div>}>*/}
                {/*    <PrivateRoute path="/digital-resources" component={DigitalResourcesPages}/>*/}
                {/*</Suspense>*/}

                {/* <Suspense fallback={
                    <div className="loader-container">
                        <div className="loader-container-inner">
                            <div className="text-center">
                                <Loader type="ball-grid-beat"/>
                            </div>
                        </div>
                    </div>}>
                    <Route path="/pages" component={Extras}/>
                </Suspense> */}

                <Route exact path="/" render={() => (
                    <Redirect to="/nsw-edu-docs"/>
                )}/>
                <ToastContainer/>
            </Fragment>
        )
    }
}

export default AppMain;