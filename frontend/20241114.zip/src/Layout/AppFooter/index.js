import React, {Fragment} from 'react';

class AppFooter extends React.Component {
    render() {
        return (
            <Fragment>
                <div className="app-footer">
                    <div className="app-footer__inner">
                        <div className="app-footer-left footer-color">
                            2019 © by DOE NSW Australia
                        </div>
                        <div className="app-footer-right footer-color">
                            Version 1.0.0
                        </div>
                    </div>
                </div>
            </Fragment>
        )
    }
}

export default AppFooter;