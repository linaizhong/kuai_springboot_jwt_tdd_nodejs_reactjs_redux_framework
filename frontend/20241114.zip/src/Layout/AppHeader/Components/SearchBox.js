import React, {Fragment} from 'react';
import cx from 'classnames';
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";

class SearchBox extends React.Component {
    constructor(props, context) {
        super(props, context);

        this.state = {
            // activeSearch: false,
            name: ""
        };

        this.handleChange = this.handleChange.bind(this)
        this.search1 = this.search1.bind(this)
        this.search2 = this.search2.bind(this)
    }

    handleChange(e) {
        this.setState({
            name: e.target.value
        })
    }

    search1(e) {
        console.log(e);

        if(e.keyCode === 13) {
            const {history} = this.props;

            const action = '/nsw-edu-docs/doc/search?keywords=' + this.state.name.trim();
            history.push(`${action}`);

            window.location.reload();
        } else {
            this.setState({
                name: e.target.value
            })
        }
    }

    search2(e) {
        const {history} = this.props;

        const action = '/nsw-edu-docs/doc/search?keywords=' + this.state.name.trim();
        history.push(`${action}`);

        window.location.reload();
    }

    render() {
        return (
            <Fragment>
                <div className={cx("search-wrapper", {
                    // 'active': this.state.activeSearch
                    'active': true
                })}>
                    <div className="input-holder">
                        <input type="text" className="search-input" placeholder="Type to search" onKeyUp={event => this.search1(event)} onChange={event => this.handleChange(event)} value={this.state.name} />
                        <button onClick={(event) => this.search2(event)} className="search-icon"><span/></button>
                    </div>
                    {/*<button onClick={(event) => this.searchResults(event)} className="close"/>*/}
                </div>
            </Fragment>
        )
    }
}

function mapStateToProps(state) {
    return {
    };
}

const connectedSearch = withRouter(connect(mapStateToProps)(SearchBox));
export {connectedSearch as SearchBox};
