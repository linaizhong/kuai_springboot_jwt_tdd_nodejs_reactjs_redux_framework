import React, {Component, Fragment} from 'react';
import {withRouter} from 'react-router-dom';

import MetisMenu from 'react-metismenu';

import {NswEducationalDocument, OperationalKnowledgeHubGroup, SampleServiceGroup, DigitalResource, EducationalDataLake, LearningAnalytics, KafkaSIFStudentData} from './NavItems';

class Nav extends Component {

    state = {};

    render() {
        return (
            <Fragment>
                {/*<h5 className="app-sidebar__heading">NSW Educational Documents</h5>*/}
                <MetisMenu content={NswEducationalDocument}
                           activeLinkFromLocation
                           className="vertical-nav-menu"
                           iconNamePrefix=""
                           classNameStateIcon="pe-7s-angle-down"/>
                {/*<h5 className="app-sidebar__heading">Operational Knowledge Hub</h5>*/}
                {/*<MetisMenu content={DigitalResource}*/}
                {/*           activeLinkFromLocation*/}
                {/*           className="vertical-nav-menu"*/}
                {/*           iconNamePrefix=""*/}
                {/*           classNameStateIcon="pe-7s-angle-down"/>*/}
                {/*<h5 className="app-sidebar__heading">Operational Knowledge Hub</h5>*/}
                {/*<MetisMenu content={OperationalKnowledgeHubGroup}*/}
                {/*           activeLinkFromLocation*/}
                {/*           className="vertical-nav-menu"*/}
                {/*           iconNamePrefix=""*/}
                {/*           classNameStateIcon="pe-7s-angle-down"/>*/}
                {/*<h5 className="app-sidebar__heading">Learning Analytics</h5>*/}
                {/*<MetisMenu content={LearningAnalytics}*/}
                {/*           activeLinkFromLocation*/}
                {/*           className="vertical-nav-menu"*/}
                {/*           iconNamePrefix=""*/}
                {/*           classNameStateIcon="pe-7s-angle-down"/>*/}
                {/*<h5 className="app-sidebar__heading">SIF Student Data PoC</h5>*/}
                {/*<MetisMenu content={KafkaSIFStudentData}*/}
                {/*           activeLinkFromLocation*/}
                {/*           className="vertical-nav-menu"*/}
                {/*           iconNamePrefix=""*/}
                {/*           classNameStateIcon="pe-7s-angle-down"/>*/}
                {/*<h5 className="app-sidebar__heading">Educational Data Lake</h5>*/}
                {/*<MetisMenu content={EducationalDataLake}*/}
                {/*           activeLinkFromLocation*/}
                {/*           className="vertical-nav-menu"*/}
                {/*           iconNamePrefix=""*/}
                {/*           classNameStateIcon="pe-7s-angle-down"/>*/}
            </Fragment>
        );
    }

    isPathActive(path) {
        return this.props.location.pathname.startsWith(path);
    }
}

export default withRouter(Nav);