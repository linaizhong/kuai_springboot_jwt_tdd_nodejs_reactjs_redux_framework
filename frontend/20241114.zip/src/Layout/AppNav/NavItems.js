export const NswEducationalDocument = [
    {
        icon: 'pe-7s-news-paper',
        label: 'Curriculum Hub',
        content: [
            {
                label: 'Standards',
                content: [
                    {
                        label: 'Australian Professional Standards for Teachers',
                        to: '#/nsw-edu-docs/standard/apst',
                    },
                    {
                        label: 'NSW Schools Business Capabilities Model',
                        to: '#/nsw-edu-docs/standard/sbcm',
                    },
                    {
                        label: 'ICT Maturity Framework',
                        to: '#/nsw-edu-docs/standard/imf',
                    },
                    {
                        label: 'SEF SDS Considerations',
                        to: '#/nsw-edu-docs/standard/sef-sdsc',
                    }
                ]
            }, {
                label: 'Australian Curriculum',
                content: [{
                    label: 'Australian Curriculum F-10',
                    to: '#/nsw-edu-docs/curriculum'
                }, {
                    label: 'National Literacy Learning Progression',
                    to: '#/nsw-edu-docs/nllps'
                }, {
                    label: 'National Numeracy Learning Progression',
                    to: '#/nsw-edu-docs/nnlps'
                }]
            }, {
                label: 'NSW Syllabus',
                content: [
                    {
                        label: 'English',
                        to: '#/nsw-edu-docs/syllabus/k10/english',
                    },
                    {
                        label: 'Mathematics',
                        to: '#/nsw-edu-docs/syllabus/k10/mathematics',
                    },
                    {
                        label: 'Chemistry',
                        to: '#/nsw-edu-docs/syllabus/k10/chemistry',
                    },
                    {
                        label: 'Geography',
                        to: '#/nsw-edu-docs/syllabus/k10/geography',
                    },
                    {
                        label: 'Music',
                        to: '#/nsw-edu-docs/syllabus/k10/music',
                    }
                ]
            }, {
                label: 'Learning Resources',
                to: '#/nsw-edu-docs/lrs'
            }, {
                label: 'Test',
                to: '#/nsw-edu-docs/test'
            }
        ]
    }
];
