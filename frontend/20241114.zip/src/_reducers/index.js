import {combineReducers} from 'redux';

import {authentication} from './authentication.reducer';
import {alert} from './alert.reducer';
import {themeOptions} from './theme-options.reducer';


export default combineReducers({
    authentication,
    alert,
    themeOptions
});