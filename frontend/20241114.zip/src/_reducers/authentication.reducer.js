import {userConstants} from '../_constants';

export function authentication(state = {}, action) {
    switch (action.type) {
        case userConstants.LOGIN_REQUEST:
            return {
                loggingIn: true,
                username: action.username
            };
        case userConstants.LOGIN_SUCCESS:
            const {username, firstName, lastName} = action;
            return {
                loggedIn: true,
                username, firstName, lastName
            };
        case userConstants.LOGIN_FAILURE:
            return {};
        case userConstants.LOGOUT:
            return {};
        default:
            return state
    }
}