import {alertConstants} from '../_constants';
import {
    toast,
    Bounce
} from 'react-toastify';

export const alertActions = {
    success,
    error,
    clear
};

function success(message) {
    toast(message, {
        transition: Bounce,
        closeButton: true,
        autoClose: 3000,
        position: 'bottom-center',
        type: 'success'
    });
    return {type: alertConstants.SUCCESS, message};
}

function error(message) {
    toast(message, {
        transition: Bounce,
        closeButton: true,
        autoClose: 3000,
        position: 'bottom-center',
        type: 'error'
    });
    return {type: alertConstants.ERROR, message};
}

function clear() {
    return {type: alertConstants.CLEAR};
}