import {userConstants} from '../_constants';
import {userService} from '../_services';
import {alertActions} from './';

export const userActions = {
    login,
    logout
};

function login(history, username, password) {
    return dispatch => {
        // dispatch(request({username}));

        // userService.login(username, password)
        //     .then(
        //         token => {
        //             // const username = userService.getClaim('user_name');
        //             // const firstName = userService.getClaim("firstName");
        //             // const lastName = userService.getClaim("lastName");
        //             const username = 'admin@emp.nsw.edu.au';
        //             const firstName = 'Alan';
        //             const lastName = 'Lin';
        //             dispatch(success({username, firstName, lastName, token}));
        //             // history.push('/digital-resources');
        //             history.push('/nsw-edu-docs/standards');
        //         },
        //         error => {
        //             dispatch(failure(error));
        //             dispatch(alertActions.error(error));
        //         }
        //     );

        const username = 'admin@emp.nsw.edu.au';
        const firstName = 'Alan';
        const lastName = 'Lin';
        dispatch(success({username, firstName, lastName, token}));
        // history.push('/digital-resources');
        history.push('/nsw-edu-docs/standards');
    };

    function request(username) {
        return {type: userConstants.LOGIN_REQUEST, username}
    }

    function success({username, firstName, lastName, token}) {
        return {type: userConstants.LOGIN_SUCCESS, username, firstName, lastName, token}
    }

    function failure(error) {
        return {type: userConstants.LOGIN_FAILURE, error}
    }
}

function logout() {
    userService.logout();
    return {type: userConstants.LOGOUT};
}