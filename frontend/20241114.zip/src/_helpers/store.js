import {createStore, applyMiddleware} from 'redux';
import thunkMiddleware from 'redux-thunk';
import {createLogger} from 'redux-logger';
import appReducer from '../_reducers';
//import {persistStore, persistReducer} from 'redux-persist'
import storage from 'redux-persist/lib/storage'
import {userConstants} from "../_constants";

const loggerMiddleware = createLogger();

const persistConfig = {
    key: 'root',
    storage,
};

const rootReducer = (state, action) => {
    if (action.type === userConstants.LOGOUT) {
        state = undefined
    }

    return appReducer(state, action)
};

//const persistedReducer = persistReducer(persistConfig, rootReducer);

const store = createStore(
    //persistedReducer,
    rootReducer,
    applyMiddleware(
        thunkMiddleware,
        loggerMiddleware
    )
);

//const persistor = persistStore(store);

export {store};