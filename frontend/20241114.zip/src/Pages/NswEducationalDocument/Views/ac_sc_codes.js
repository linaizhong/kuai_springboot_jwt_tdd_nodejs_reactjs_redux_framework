export const sccodes = [
  {name: 'ACSIS203', value: 'ACSIS203'},
  {name: 'ACSIS148', value: 'ACSIS148'},
  {name: 'ACSIS206', value: 'ACSIS206'}, 
  // {name: '', value: ''}, 
  {name: 'ACSIS139', value: 'ACSIS139'} 
]
  