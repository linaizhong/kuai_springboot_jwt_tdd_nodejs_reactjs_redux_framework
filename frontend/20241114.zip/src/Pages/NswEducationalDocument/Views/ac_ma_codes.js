export const macodes = [
  {name: 'ACMMG274', value: 'ACMMG274'},
  {name: 'ACMSP278', value: 'ACMSP278'},
  {name: 'ACMMG065', value: 'ACMMG065'}, 
  // {name: '', value: ''}, 
  {name: 'ACMMG023', value: 'ACMMG023'} 
]
  