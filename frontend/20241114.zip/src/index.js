import React from 'react';
import {render} from 'react-dom';

import * as serviceWorker from './serviceWorker';
import './assets/app.scss';
import Main from './Pages/Main';
import {Provider} from 'react-redux';
import {HashRouter} from "react-router-dom";
import {store} from './_helpers';
import {createHttpLink} from "apollo-link-http";
import {setContext} from "apollo-link-context";
import ApolloClient from "apollo-client";
import {ApolloProvider} from "react-apollo";
import {InMemoryCache} from "apollo-cache-inmemory";
import {userService} from "./_services";

const httpLink = createHttpLink({
    uri: `/graphql`,
});

const authLink = setContext((_, {headers}) => {
    const token = userService.getToken();
    return {
        headers: {
            ...headers,
            Authorization: token ? `Bearer ${token}` : ``,
        }
    }
});

const client = new ApolloClient({
    link: authLink.concat(httpLink),
    cache: new InMemoryCache()
});

render(
    <ApolloProvider client={client}>
        <Provider store={store}>
            <HashRouter>
                <Main/>
            </HashRouter>
        </Provider>
    </ApolloProvider>,
    document.getElementById('root')
);

serviceWorker.unregister();
