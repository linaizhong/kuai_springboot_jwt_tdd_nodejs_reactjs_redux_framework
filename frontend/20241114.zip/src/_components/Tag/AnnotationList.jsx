import React from "react";
import {connect} from "react-redux";
import {Chip, withStyles} from "@material-ui/core";
import {Col, Row} from "reactstrap";
import PlaceIcon from '@material-ui/icons/Place';
import PersonIcon from '@material-ui/icons/Person';
import OrganizationIcon from '@material-ui/icons/Business';
import WorkIcon from '@material-ui/icons/Work';
import SpeciesIcon from '@material-ui/icons/LocalFlorist';
import UnknownIcon from '@material-ui/icons/TurnedIn';

const styles = theme => ({
    chip: {
        margin: theme.spacing(0.5),
    },
});

class AnnotationList extends React.Component {

    constructor(props) {
        super(props);
        // this.handleResourceClick = this.handleResourceClick.bind(this);
        // this.handleResourceUnselect = this.handleResourceUnselect.bind(this);
    }

    handleResourceClick(annotation) {
        if (annotation.selected)
            return;
        const {dispatch} = this.props;
        // dispatch(digitalResourceActions.selectAnnotation(annotation))
    }

    handleResourceUnselect(annotation) {
        if (!annotation.selected)
            return;
        const {dispatch} = this.props;
        // dispatch(digitalResourceActions.unselectAnnotation(annotation))
    }

    sortBySelected(resources) {
        return resources.sort((a, b) => a.selected === true ? b.selected === true ? 0 : -1 : b.selected === true ? 1 : 0);
    }

    getAvatar(annotation) {
        const types = annotation.types;
        if (!types)
            return <UnknownIcon/>;
        if (types.indexOf("Organization") > -1) {
            return <OrganizationIcon/>;
        } else if (types.indexOf("Person") > -1) {
            return <PersonIcon/>;
        } else if (types.indexOf("Place") > -1) {
            return <PlaceIcon/>;
        } else if (types.indexOf("Work") > -1) {
            return <WorkIcon/>;
        } else if (types.indexOf("Species") > -1) {
            return <SpeciesIcon/>
        } else return <UnknownIcon/>;
    }

    render() {
        const {
            classes,
            annotations,
            extractedFrom
        } = this.props;

        let sortedAnnotations = this.sortBySelected(annotations.flatMap(
            annotation => annotation.resources.map(resource => ({
                uri: resource.uri,
                surfaceForm: resource.surfaceForm,
                selected: resource.selected,
                extractedFrom: annotation.extractedFrom,
                types: resource.types
            }))));

        if (extractedFrom) {
            sortedAnnotations = sortedAnnotations.filter(a => a.extractedFrom === extractedFrom);
        }

        return (
            <Row>
                <Col>
                    {sortedAnnotations.map(annotation => (
                        <Chip
                            icon={this.getAvatar(annotation)}
                            key={`${annotation.extractedFrom}:${annotation.uri}`}
                            label={annotation.surfaceForm}
                            className={classes.chip}
                            color={annotation.selected ? 'primary' : 'default'}
                            onDelete={annotation.selected ? (() => this.handleResourceUnselect(annotation)) : null}
                            onClick={annotation.selected ? null : (() => this.handleResourceClick(annotation))}/>
                    ))}

                </Col>
            </Row>
        );
    }
}

function mapStateToProps(state) {
    const {annotations} = state.digitalResource;
    return {annotations};
}

const connectedAnnotationList = connect(mapStateToProps)(withStyles(styles)(AnnotationList));
export {connectedAnnotationList as AnnotationList};
