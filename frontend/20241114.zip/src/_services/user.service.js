import {handleResponse} from "../_helpers";
import jwtDecode from 'jwt-decode';

const clientId = `${process.env.REACT_APP_CLIENT_ID}`;
const clientPassword = `${process.env.REACT_APP_CLIENT_PASSWORD}`;

export const userService = {
    login,
    logout,
    getToken,
    getClaim
};

function login(username, password) {
    const credentials = `${clientId}:${clientPassword}`;
    const requestOptions = {
        method: 'POST',
        headers: {'Authorization': `Basic ${window.btoa(credentials)}`}
    };

    return fetch(`/oauth/token?grant_type=password&username=${username}&password=${password}`, requestOptions)
        .then(handleResponse)
        .then(response => {
            localStorage.setItem('token', response.access_token);
            return response.access_token;
        });
}

function logout() {
    localStorage.removeItem('token');
}

function getClaim(claim) {
    const json = decodeJwt();
    return json ? json[claim] : null;
}

function decodeJwt() {
    const token = getToken();
    return token ? jwtDecode(token) : null
}


function getToken() {
    return localStorage.getItem('token');
}
