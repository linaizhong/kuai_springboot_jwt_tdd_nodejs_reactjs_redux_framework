import {authHeader, handleResponse} from "../_helpers";

const MODULE = 'doe-doc-apis'

class EducationalDocumentService {
    getStandards() {
        const requestOptions = {
            method: 'GET',
            headers: Object.assign({},
                authHeader(),
                {'Content-Type': 'application/json'})
        };

        return fetch(`/${MODULE}/edu-docs/standards`, requestOptions)
            .then(handleResponse)
            .then(response => {
                return response
            })
    }

    getAllTerminologies() {
        const requestOptions = {
            method: 'GET',
            headers: Object.assign({},
                authHeader(),
                {'Content-Type': 'application/json'})
        };

        return fetch(`/${MODULE}/edu-docs/terminologies/all`, requestOptions)
            .then(handleResponse)
            .then(response => {
                return response
            })
    }

    getCurriculum() {
        const requestOptions = {
            method: 'GET',
            headers: Object.assign({},
                authHeader(),
                {'Content-Type': 'application/json'})
        };

        return fetch(`/${MODULE}/edu-docs/curriculum`, requestOptions)
            .then(handleResponse)
            .then(response => {
                return response
            })
    }

    saveDictionary(dictionary) {
        // console.log(dictionary);

        let items = {};
        Object.keys(dictionary).map(
            key => {
                items = {
                    ...items,
                    [key]: dictionary[key]
                }
            }
        )

        console.log(items);

        const requestOptions = {
            method: 'POST',
            headers: Object.assign({},
                authHeader(),
                {'Content-Type': 'application/json'}),
            body: JSON.stringify({items})
        };

        return fetch(`/${MODULE}/edu-docs/dictionary/items`, requestOptions)
            .then(handleResponse)
            .then(response => {
                return response
            })
    }

    search(keywords) {
        // console.log(keywords);

        const requestOptions = {
            method: 'POST',
            headers: Object.assign({},
                authHeader(),
                {'Content-Type': 'application/json'}),
            body: JSON.stringify({keywords})
        };

        return fetch(`/${MODULE}/edu-docs/search`, requestOptions)
            .then(handleResponse)
            .then(response => {
                return response
            })
    }

    synonyms(keywords) {
        // console.log(keywords);

        const requestOptions = {
            method: 'POST',
            headers: Object.assign({},
                authHeader(),
                {'Content-Type': 'application/json'}),
            body: JSON.stringify({keywords})
        };

        return fetch(`/${MODULE}/edu-docs/synonyms`, requestOptions)
            .then(handleResponse)
            .then(response => {
                return response
            })
    }

    saveResource(item) {
        console.log(item);

        const requestOptions = {
            method: 'POST',
            headers: Object.assign({},
                authHeader(),
                {'Content-Type': 'application/json'}),
            body: JSON.stringify({item})
        };

        return fetch(`/${MODULE}/edu-docs/resource`, requestOptions)
            .then(handleResponse)
            .then(response => {
                return response
            })
    }

    uploadFile(formData) {
        console.log("uploadFile");

        const requestOptions = {
            method: 'POST',
            headers: Object.assign({}, authHeader()),
            body: formData
        };

        return fetch(`/${MODULE}/edu-docs/image`, requestOptions)
            .then(handleResponse)
            .then(response => {
                return response
            });
    }

    getCurriculum(label) {
        const requestOptions = {
            method: 'POST',
            headers: Object.assign({},
                authHeader(),
                {'Content-Type': 'application/json'}),
            body: JSON.stringify({label})
        };

        return fetch(`/${MODULE}/edu-docs/curriculum`, requestOptions)
            .then(handleResponse)
            .then(response => {
                return response
            })
    }

    getLectureResources(label) {
        const requestOptions = {
            method: 'POST',
            headers: Object.assign({},
                authHeader(),
                {'Content-Type': 'application/json'}),
            body: JSON.stringify({label})
        };

        return fetch(`/${MODULE}/edu-docs/lecture-resources`, requestOptions)
            .then(handleResponse)
            .then(response => {
                return response
            })
    }

    getSearchDetails(id, type) {
        const requestOptions = {
            method: 'POST',
            headers: Object.assign({},
                authHeader(),
                {'Content-Type': 'application/json'}),
            body: JSON.stringify({id, type})
        };

        return fetch(`/${MODULE}/edu-docs/search-details`, requestOptions)
            .then(handleResponse)
            .then(response => {
                return response
            })
    }

    saveTerminology(term) {
        console.log(term);

        const requestOptions = {
            method: 'POST',
            headers: Object.assign({},
                authHeader(),
                {'Content-Type': 'application/json'}),
            body: JSON.stringify({term})
        };

        return fetch(`/${MODULE}/edu-docs/terminology`, requestOptions)
            .then(handleResponse)
            .then(response => {
                return response
            })
    }

    getLinkGraph(results) {
        const requestOptions = {
            method: 'POST',
            headers: Object.assign({},
                authHeader(),
                {'Content-Type': 'application/json'}),
            body: JSON.stringify(results)
        };

        return fetch(`/${MODULE}/edu-docs/link-graph`, requestOptions)
            .then(handleResponse)
            .then(response => {
                return response
            })
    }

    //
    // createBucket(bucketName) {
    //     console.log("Bucket name: " + bucketName);
    //
    //     const requestOptions = {
    //         method: 'POST',
    //         headers: Object.assign({},
    //             authHeader(),
    //             {'Content-Type': 'application/json'}),
    //         body: JSON.stringify({bucketName})
    //     };
    //
    //     return fetch(`/${MODULE}/bucket`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
    //
    // deleteBucket(bucketName) {
    //     const requestOptions = {
    //         method: 'DELETE',
    //         headers: Object.assign({},
    //             authHeader(),
    //             {'Content-Type': 'application/json'}),
    //         body: JSON.stringify({bucketName})
    //     };
    //
    //     return fetch(`/${MODULE}/bucket`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
    //
    // openBucket(bucketName) {
    //     const requestOptions = {
    //         method: 'POST',
    //         headers: Object.assign({},
    //             authHeader(),
    //             {'Content-Type': 'application/json'}),
    //         body: JSON.stringify({bucketName})
    //     };
    //
    //     return fetch(`/${MODULE}/bucket/objects`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
    //
    // uploadFile(bucketname, formData) {
    //     return axios.post(
    //         `/${MODULE}/bucket/${bucketname}/object`,
    //         formData,
    //         {headers: Object.assign({},
    //                 authHeader(),
    //                 {'Content-Type': 'application/json'})}
    //     );
    // }
    //
    // // downloadObject(bucketName, objectKey) {
    // //     const requestOptions = {
    // //         method: 'GET',
    // //         headers: Object.assign({},
    // //             authHeader())
    // //     };
    // //
    // //     return fetch(`/${MODULE}/bucket/object?bucketName=${bucketName}&objectKey=${encodeURIComponent(objectKey)}`, requestOptions);
    // // }
    //
    // extractSheets(bucketName, objectKey) {
    //     const requestOptions = {
    //         method: 'POST',
    //         headers: Object.assign({},
    //             authHeader(),
    //             {'Content-Type': 'application/json'}),
    //         body: JSON.stringify({bucketName, objectKey})
    //     };
    //
    //     return fetch(`/${MODULE}/bucket/object/extract`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
    //
    // deleteObject(bucketName, objectKey) {
    //     const requestOptions = {
    //         method: 'DELETE',
    //         headers: Object.assign({},
    //             authHeader(),
    //             {'Content-Type': 'application/json'}),
    //         body: JSON.stringify({bucketName, objectKey})
    //     };
    //
    //     return fetch(`/${MODULE}/bucket/object`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
    //
    // openMappingRules(bucketName) {
    //     const requestOptions = {
    //         method: 'POST',
    //         headers: Object.assign({},
    //             authHeader(),
    //             {'Content-Type': 'application/json'}),
    //         body: JSON.stringify({bucketName})
    //     };
    //
    //     return fetch(`/${MODULE}/mapping/rules`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
    //
    // saveMappingRules(bucketName, rules) {
    //     console.log(rules);
    //
    //     const requestOptions = {
    //         method: 'POST',
    //         headers: Object.assign({},
    //             authHeader(),
    //             {'Content-Type': 'application/json'}),
    //         body: JSON.stringify({rules})
    //     };
    //
    //     return fetch(`/${MODULE}/${bucketName}/mapping/rules`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
    //
    // openReferencingRules(bucketName) {
    //     const requestOptions = {
    //         method: 'POST',
    //         headers: Object.assign({},
    //             authHeader(),
    //             {'Content-Type': 'application/json'}),
    //         body: JSON.stringify({bucketName})
    //     };
    //
    //     return fetch(`/${MODULE}/referencing/rules`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
    //
    // saveReferencingRules(bucketName, rules) {
    //     console.log(rules);
    //
    //     const requestOptions = {
    //         method: 'POST',
    //         headers: Object.assign({},
    //             authHeader(),
    //             {'Content-Type': 'application/json'}),
    //         body: JSON.stringify({rules})
    //     };
    //
    //     return fetch(`/${MODULE}/${bucketName}/referencing/rules`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
    //
    // openDataProcesses(bucketName) {
    //     const requestOptions = {
    //         method: 'GET',
    //         headers: Object.assign({},
    //             authHeader())
    //     };
    //
    //     return fetch(`/${MODULE}/${bucketName}/processes`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
    //
    // saveDataProcesses(bucketName, processes) {
    //     const requestOptions = {
    //         method: 'POST',
    //         headers: Object.assign({},
    //             authHeader(),
    //             {'Content-Type': 'application/json'}),
    //         body: JSON.stringify({processes})
    //     };
    //
    //     return fetch(`/${MODULE}/${bucketName}/processes`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
    //
    // executeProcess(bucketName, process) {
    //     console.log(process);
    //
    //     const requestOptions = {
    //         method: 'POST',
    //         headers: Object.assign({},
    //             authHeader(),
    //             {'Content-Type': 'application/json'}),
    //         body: JSON.stringify({process})
    //     };
    //
    //     return fetch(`/${MODULE}/${bucketName}/process/execution`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
    //
    // openDataTables(bucketName) {
    //     const requestOptions = {
    //         method: 'GET',
    //         headers: Object.assign({},
    //             authHeader())
    //     };
    //
    //     return fetch(`/${MODULE}/${bucketName}/report/tables`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
    //
    // showTable(bucketName, table) {
    //     const requestOptions = {
    //         method: 'POST',
    //         headers: Object.assign({},
    //             authHeader(),
    //             {'Content-Type': 'application/json'}),
    //         body: JSON.stringify({table})
    //     };
    //
    //     return fetch(`/${MODULE}/${bucketName}/report/table`, requestOptions)
    //         .then(handleResponse)
    //         .then(response => {
    //             return response
    //         })
    // }
}

export default new EducationalDocumentService()
