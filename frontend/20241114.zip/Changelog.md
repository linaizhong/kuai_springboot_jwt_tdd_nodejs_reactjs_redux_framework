### Changelog

## Version 1.1.1 (27 December 2018)


## Version 2.0.0 (16 April 2019)
 - Updated all package.json dependencies to latest versions.
 - Fixed tabs issue
 - various bug fixes
